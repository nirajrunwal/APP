// ─────────────────────────────────────────────────────────────────
// lib/features/location/services/background_location_service.dart
// flutter_background_service — runs in Android foreground service
// Uploads GPS every 1 hour + handles device boot restart
// ─────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/services/api_service.dart';

// ── Notification channel constants ───────────────────────────
const _channelId   = 'agri_tracking_channel';
const _channelName = 'AgriLoyalty Location Tracking';
const _notifId     = 888;

class BackgroundLocationService {
  static const _uploadIntervalSeconds = 3600; // 1 hour

  // ── Call once in main() ──────────────────────────────────────
  static Future<void> initialize() async {
    final service = FlutterBackgroundService();

    const androidConfig = AndroidConfiguration(
      onStart:            onStart,
      isForegroundMode:   true,
      autoStart:          false,
      notificationChannelId: _channelId,
      initialNotificationTitle:   'AgriLoyalty Active',
      initialNotificationContent: 'Location tracking is running',
      foregroundServiceNotificationId: _notifId,
      // Restart on boot
      autoStartOnBoot: true,
    );

    await service.configure(
      androidConfiguration: androidConfig,
      iosConfiguration: const IosConfiguration(autoStart: false),
    );
  }

  static Future<void> startService() async {
    final service = FlutterBackgroundService();
    await service.startService();
  }

  static Future<void> stopService() async {
    final service = FlutterBackgroundService();
    service.invoke('stopService');
  }

  static Future<bool> isRunning() async {
    return FlutterBackgroundService().isRunning();
  }
}

// ── Background isolate entry point ───────────────────────────
// Must be a top-level function (not a class method)
@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  // ── Setup notification channel
  final notificationsPlugin = FlutterLocalNotificationsPlugin();
  await notificationsPlugin.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
  );

  const androidNotifChannel = AndroidNotificationChannel(
    _channelId,
    _channelName,
    importance: Importance.low,
    enableVibration: false,
    playSound: false,
  );

  await notificationsPlugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(androidNotifChannel);

  // ── Handle stop command
  service.on('stopService').listen((event) {
    service.stopSelf();
  });

  // ── Upload on interval
  Timer.periodic(const Duration(seconds: _uploadIntervalSeconds), (_) async {
    await _uploadLocation(service, notificationsPlugin);
  });

  // ── Also upload immediately when service starts
  await _uploadLocation(service, notificationsPlugin);
}

Future<void> _uploadLocation(
  ServiceInstance service,
  FlutterLocalNotificationsPlugin notifications,
) async {
  try {
    final prefs  = await SharedPreferences.getInstance();
    final userID = prefs.getString('userID') ?? '';
    if (userID.isEmpty) return;

    // Check & request permission
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return;

    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 20),
      ),
    );

    final locationData = {
      'userID':    userID,
      'latitude':  position.latitude,
      'longitude': position.longitude,
      'timestamp': DateTime.now().toIso8601String(),
    };

    final breaches = await ApiService().batchUploadLocations([locationData]);

    // Notify if proximity breach
    if (breaches.isNotEmpty) {
      await notifications.show(
        _notifId + 1,
        '🚨 Near Shop!',
        'You are within ${AppConstants.defaultGeofenceRadius.toInt()}m of the shop.',
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            _channelName,
            importance: Importance.high,
            priority:   Priority.high,
            channelShowBadge: true,
          ),
        ),
      );
    }

    // Persist last known position for foreground display
    await prefs.setDouble('lastLat', position.latitude);
    await prefs.setDouble('lastLon', position.longitude);
    await prefs.setString('lastLocationTs', DateTime.now().toIso8601String());

    // Send event to foreground (if app is open)
    service.invoke('locationUpdate', {
      'lat': position.latitude,
      'lon': position.longitude,
      'ts':  DateTime.now().toIso8601String(),
      'breach': breaches.isNotEmpty,
    });
  } catch (e) {
    // Silently fail — will retry on next interval
  }
}
