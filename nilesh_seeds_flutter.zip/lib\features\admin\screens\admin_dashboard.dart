// ─────────────────────────────────────────────────────────────────
// lib/features/admin/screens/admin_dashboard.dart
// Admin control panel with live polling, farmer list, proximity alerts
// ─────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/models/user_model.dart';
import '../../auth/providers/auth_provider.dart';
import '../providers/admin_provider.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late Timer _pollingTimer;
  int _currentTab = 0;
  String _searchQuery = '';
  final _searchCtr = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this)
      ..addListener(() => setState(() => _currentTab = _tabController.index));
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    final admin = context.read<AdminProvider>();
    await admin.refresh();

    _pollingTimer = Timer.periodic(
      const Duration(seconds: AppConstants.adminPollingSeconds),
      (_) => context.read<AdminProvider>().refresh(),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    _pollingTimer.cancel();
    _searchCtr.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<AdminProvider, AuthProvider>(
      builder: (context, admin, auth, _) {
        return Scaffold(
          backgroundColor: AppColors.bgBase,
          appBar: _buildAppBar(auth, admin),
          body: TabBarView(
            controller: _tabController,
            physics: const BouncingScrollPhysics(),
            children: [
              _buildOverviewTab(admin),
              _buildFarmersTab(admin),
              _buildAlertsTab(admin),
            ],
          ),
          floatingActionButton: _currentTab == 1
              ? FloatingActionButton(
                  backgroundColor: AppColors.primaryGlow,
                  onPressed: () => _showRegisterDialog(context, admin),
                  child: const Icon(Icons.person_add, color: Colors.white),
                ).animate().scale(delay: 100.ms)
              : null,
        );
      },
    );
  }

  AppBar _buildAppBar(AuthProvider auth, AdminProvider admin) {
    return AppBar(
      backgroundColor: AppColors.bgSurface,
      title: Column(
        children: [
          const Text('Admin Dashboard', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          Text('Polling every ${AppConstants.adminPollingSeconds}s',
            style: const TextStyle(color: AppColors.textHint, fontSize: 11)),
        ],
      ),
      actions: [
        if (admin.isLoading)
          const Padding(
            padding: EdgeInsets.all(14),
            child: SizedBox(width: 18, height: 18,
              child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primaryGlow)),
          )
        else
          IconButton(icon: const Icon(Icons.refresh), onPressed: admin.refresh),
        IconButton(
          icon: const Icon(Icons.logout, color: AppColors.textSecondary),
          onPressed: () async {
            await auth.logout();
            if (mounted) Navigator.pushReplacementNamed(context, '/login');
          },
        ),
      ],
      bottom: TabBar(
        controller: _tabController,
        indicatorColor: AppColors.primaryGlow,
        labelColor: AppColors.primaryGlow,
        unselectedLabelColor: AppColors.textHint,
        tabs: const [
          Tab(text: 'Overview', icon: Icon(Icons.dashboard_outlined, size: 18)),
          Tab(text: 'Farmers',  icon: Icon(Icons.group_outlined, size: 18)),
          Tab(text: 'Alerts',   icon: Icon(Icons.notifications_outlined, size: 18)),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // TAB 1 — OVERVIEW
  // ════════════════════════════════════════════════════════════
  Widget _buildOverviewTab(AdminProvider admin) {
    return RefreshIndicator(
      color: AppColors.primaryGlow,
      backgroundColor: AppColors.bgCard,
      onRefresh: admin.refresh,
      child: ListView(
        padding: const EdgeInsets.all(20),
        physics: const BouncingScrollPhysics(),
        children: [
          _buildKPIRow(admin),
          const SizedBox(height: 20),
          _buildRecentBreachesCard(admin),
          const SizedBox(height: 20),
          _buildRecentLogsCard(admin),
        ],
      ),
    );
  }

  Widget _buildKPIRow(AdminProvider admin) {
    return Row(
      children: [
        Expanded(child: _kpiCard(
          'Total Farmers', '${admin.farmers.length}', Icons.agriculture, AppColors.primaryGlow)),
        const SizedBox(width: 12),
        Expanded(child: _kpiCard(
          'Active (1h)', '${admin.activeFarmerCount}', Icons.gps_fixed, AppColors.accent)),
        const SizedBox(width: 12),
        Expanded(child: _kpiCard(
          'Near Alerts', '${admin.recentBreaches.length}', Icons.place, AppColors.warning)),
      ],
    ).animate().fadeIn().slideY(begin: 0.2, duration: 400.ms);
  }

  Widget _kpiCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 10),
          Text(value, style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: AppColors.textHint, fontSize: 10), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildRecentBreachesCard(AdminProvider admin) {
    final breaches = admin.recentBreaches.take(5).toList();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 20),
            const SizedBox(width: 8),
            const Text('Proximity Alerts', style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
            const Spacer(),
            if (breaches.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                child: Text('${breaches.length}', style: const TextStyle(color: AppColors.warning, fontSize: 11, fontWeight: FontWeight.w700)),
              ),
          ]),
          const SizedBox(height: 14),
          if (breaches.isEmpty)
            _miniEmpty('No proximity breaches detected')
          else
            ...breaches.map((b) => _breachTile(b, admin)),
        ],
      ),
    ).animate().fadeIn(delay: 100.ms).slideY(begin: 0.2, duration: 400.ms);
  }

  Widget _breachTile(log, AdminProvider admin) {
    final name = admin.farmerName(log.userID);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.warning.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.place, color: AppColors.warning, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
              Text(_formatTs(log.timestamp), style: const TextStyle(color: AppColors.textHint, fontSize: 11)),
            ],
          )),
          IconButton(
            icon: const Icon(Icons.directions, color: AppColors.accent, size: 20),
            onPressed: () => _openMaps(log.latitude, log.longitude),
          ),
        ],
      ),
    );
  }

  void _openMaps(double lat, double lon) async {
    final url = Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lon');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  Widget _buildRecentLogsCard(AdminProvider admin) {
    final logs = admin.allLogs.take(8).toList();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [
            Icon(Icons.history, color: AppColors.primaryGlow, size: 20),
            SizedBox(width: 8),
            Text('Recent Location Updates', style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 14),
          if (logs.isEmpty) _miniEmpty('No location logs yet')
          else ...logs.map((l) => _logMiniTile(l, admin.farmerName(l.userID))),
        ],
      ),
    ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.2, duration: 400.ms);
  }

  Widget _logMiniTile(log, String name) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          CircleAvatar(radius: 14, backgroundColor: AppColors.bgElevated,
            child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
              style: const TextStyle(color: AppColors.primaryGlow, fontSize: 12, fontWeight: FontWeight.w700))),
          const SizedBox(width: 10),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w500)),
              Text('${log.latitude.toStringAsFixed(4)}, ${log.longitude.toStringAsFixed(4)}',
                style: const TextStyle(color: AppColors.textHint, fontSize: 11)),
            ],
          )),
          Text(_formatTs(log.timestamp), style: const TextStyle(color: AppColors.textHint, fontSize: 10)),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // TAB 2 — FARMERS
  // ════════════════════════════════════════════════════════════
  Widget _buildFarmersTab(AdminProvider admin) {
    final filteredFarmers = admin.farmers.where((f) {
      final nameMatches = f.name.toLowerCase().contains(_searchQuery.toLowerCase());
      final phoneMatches = f.phone.contains(_searchQuery);
      return nameMatches || phoneMatches;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: _searchCtr,
            style: const TextStyle(color: AppColors.textPrimary),
            onChanged: (val) => setState(() => _searchQuery = val),
            decoration: InputDecoration(
              labelText: 'Search Farmers',
              hintText: 'Enter name or phone number...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchCtr.clear();
                        setState(() => _searchQuery = '');
                      },
                    )
                  : null,
            ),
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            color: AppColors.primaryGlow,
            backgroundColor: AppColors.bgCard,
            onRefresh: admin.refresh,
            child: filteredFarmers.isEmpty
                ? const Center(child: Text('No matching farmers found', style: TextStyle(color: AppColors.textHint)))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    physics: const BouncingScrollPhysics(),
                    itemCount: filteredFarmers.length,
                    itemBuilder: (_, i) => _farmerCard(filteredFarmers[i], admin)
                        .animate(delay: (i * 50).ms).fadeIn().slideX(begin: 0.1),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _farmerAvatar(UserModel farmer) {
    if (farmer.profilePhoto.isEmpty) {
      return CircleAvatar(
        radius: 22,
        backgroundColor: AppColors.primary.withOpacity(0.2),
        child: Text(
          farmer.name.isNotEmpty ? farmer.name[0].toUpperCase() : 'F',
          style: const TextStyle(color: AppColors.primaryGlow, fontSize: 18, fontWeight: FontWeight.w700),
        ),
      );
    }

    if (farmer.profilePhoto.startsWith('http')) {
      return CircleAvatar(
        radius: 22,
        backgroundColor: AppColors.primary.withOpacity(0.2),
        backgroundImage: NetworkImage(farmer.profilePhoto),
      );
    }

    try {
      String base64Str = farmer.profilePhoto;
      if (base64Str.contains(',')) {
        base64Str = base64Str.split(',')[1];
      }
      final bytes = base64.decode(base64Str);
      return CircleAvatar(
        radius: 22,
        backgroundColor: AppColors.primary.withOpacity(0.2),
        backgroundImage: MemoryImage(bytes),
      );
    } catch (_) {
      return CircleAvatar(
        radius: 22,
        backgroundColor: AppColors.primary.withOpacity(0.2),
        child: Text(
          farmer.name.isNotEmpty ? farmer.name[0].toUpperCase() : 'F',
          style: const TextStyle(color: AppColors.primaryGlow, fontSize: 18, fontWeight: FontWeight.w700),
        ),
      );
    }
  }

  Widget _farmerCard(UserModel farmer, AdminProvider admin) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _farmerAvatar(farmer),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(farmer.name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w700)),
                  Text('${farmer.phone} • ${farmer.village.isNotEmpty ? farmer.village : 'गाव माहिती नाही'}',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('₹${farmer.loyaltyPoints}',
                  style: const TextStyle(color: AppColors.primaryGlow, fontSize: 18, fontWeight: FontWeight.w800)),
                const Text('balance', style: TextStyle(color: AppColors.textHint, fontSize: 10)),
              ]),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(color: AppColors.divider),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _pointsButton(
                  label: '+ Add ₹',
                  color: AppColors.success,
                  onTap: () => _showPointsDialog(context, farmer, admin, isAdd: true),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _pointsButton(
                  label: '− Deduct',
                  color: AppColors.error,
                  onTap: () => _showPointsDialog(context, farmer, admin, isAdd: false),
                ),
              ),
              const SizedBox(width: 10),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.error),
                onPressed: () => _confirmDeleteFarmer(context, farmer, admin),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _confirmDeleteFarmer(BuildContext context, UserModel farmer, AdminProvider admin) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete Farmer', style: TextStyle(color: AppColors.textPrimary)),
        content: Text('Are you sure you want to delete ${farmer.name} from the database?', style: const TextStyle(color: AppColors.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textHint)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () async {
              Navigator.pop(context);
              final msg = await admin.deleteUser(farmer.userID);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                     content: Text(msg),
                     backgroundColor: AppColors.error,
                  ),
                );
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showRegisterDialog(BuildContext context, AdminProvider admin) {
    final nameCtr = TextEditingController();
    final phoneCtr = TextEditingController();
    final passCtr = TextEditingController();
    final villageCtr = TextEditingController();
    String? photoBase64;
    
    showDialog(
      context: context,
      builder: (stateContext) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: AppColors.bgCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Register New Farmer', style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtr,
                  style: const TextStyle(color: AppColors.textPrimary),
                  decoration: const InputDecoration(labelText: 'Full Name (पूर्ण नाव)', hintText: 'e.g. Ravindra Patil'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: phoneCtr,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: AppColors.textPrimary),
                  decoration: const InputDecoration(labelText: 'Phone Number (मोबाईल नंबर)', hintText: 'e.g. 9876543210'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: passCtr,
                  obscureText: true,
                  style: const TextStyle(color: AppColors.textPrimary),
                  decoration: const InputDecoration(labelText: 'Password (पासवर्ड)', hintText: 'Set a password'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: villageCtr,
                  style: const TextStyle(color: AppColors.textPrimary),
                  decoration: const InputDecoration(labelText: 'Village (गाव)', hintText: 'e.g. Bhusawal'),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: AppColors.bgElevated,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.primaryGlow.withOpacity(0.3)),
                      ),
                      child: photoBase64 == null
                          ? const Icon(Icons.add_a_photo, color: AppColors.textHint)
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.memory(base64.decode(photoBase64!.split(',')[1]), fit: BoxFit.cover),
                            ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.photo_library, size: 16),
                        label: const Text('Select Photo'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.bgElevated,
                          foregroundColor: AppColors.textPrimary,
                        ),
                        onPressed: () async {
                          final picker = ImagePicker();
                          final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
                          if (image != null) {
                            final bytes = await image.readAsBytes();
                            final base64String = base64.encode(bytes);
                            final mimeType = 'image/${image.name.split('.').last}';
                            setState(() {
                              photoBase64 = 'data:$mimeType;base64,$base64String';
                            });
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: AppColors.textHint)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryGlow),
              onPressed: () async {
                final name = nameCtr.text.trim();
                final phone = phoneCtr.text.trim();
                final pass = passCtr.text.trim();
                final village = villageCtr.text.trim();
                if (name.isEmpty || phone.isEmpty || pass.isEmpty || village.isEmpty) {
                  ScaffoldMessenger.of(stateContext).showSnackBar(
                    const SnackBar(content: Text('Please fill all required fields'), backgroundColor: AppColors.error),
                  );
                  return;
                }
                Navigator.pop(context);
                final msg = await admin.registerUser(
                  name: name,
                  phone: phone,
                  password: pass,
                  village: village,
                  profilePhoto: photoBase64,
                );
                if (stateContext.mounted) {
                  ScaffoldMessenger.of(stateContext).showSnackBar(
                    SnackBar(content: Text(msg), backgroundColor: msg.contains('Error') ? AppColors.error : AppColors.success),
                  );
                }
              },
              child: const Text('Register'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pointsButton({required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Text(label, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // TAB 3 — ALERTS
  // ════════════════════════════════════════════════════════════
  Widget _buildAlertsTab(AdminProvider admin) {
    return RefreshIndicator(
      color: AppColors.primaryGlow,
      backgroundColor: AppColors.bgCard,
      onRefresh: admin.refresh,
      child: admin.recentBreaches.isEmpty
          ? Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.notifications_off_outlined, color: AppColors.textHint, size: 56),
                const SizedBox(height: 12),
                const Text('No proximity alerts', style: TextStyle(color: AppColors.textHint, fontSize: 16)),
                const Text('Farmers within 300m will appear here.', style: TextStyle(color: AppColors.textHint, fontSize: 13)),
              ]),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              physics: const BouncingScrollPhysics(),
              itemCount: admin.recentBreaches.length,
              itemBuilder: (_, i) {
                final b = admin.recentBreaches[i];
                return _alertTile(b, admin, i);
              },
            ),
    );
  }

  Widget _alertTile(log, AdminProvider admin, int index) {
    final name = admin.farmerName(log.userID);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.warning.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.15), shape: BoxShape.circle),
            child: const Icon(Icons.place, color: AppColors.warning, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              const Text('Within 300m of shop', style: TextStyle(color: AppColors.warning, fontSize: 12, fontWeight: FontWeight.w500)),
              Text('${log.latitude.toStringAsFixed(5)}, ${log.longitude.toStringAsFixed(5)}',
                style: const TextStyle(color: AppColors.textHint, fontSize: 11)),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(_formatTs(log.timestamp), style: const TextStyle(color: AppColors.textHint, fontSize: 10)),
            IconButton(
              icon: const Icon(Icons.directions, color: AppColors.accent, size: 20),
              onPressed: () => _openMaps(log.latitude, log.longitude),
            ),
          ]),
        ],
      ),
    ).animate(delay: (index * 50).ms).fadeIn().slideX(begin: 0.1);
  }

  void _showPointsDialog(BuildContext context, UserModel farmer, AdminProvider admin, {required bool isAdd}) {
    final ctr = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          isAdd ? 'Add Points to ${farmer.name}' : 'Deduct Points from ${farmer.name}',
          style: const TextStyle(color: AppColors.textPrimary, fontSize: 17),
        ),
        content: TextField(
          controller: ctr,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: InputDecoration(
            labelText: 'Loyalty Points (Rupees)',
            hintText: 'Enter amount in ₹',
            prefixIcon: Icon(isAdd ? Icons.add : Icons.remove, color: isAdd ? AppColors.success : AppColors.error),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textHint)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isAdd ? AppColors.success : AppColors.error,
            ),
            onPressed: () async {
              final pts = int.tryParse(ctr.text.trim()) ?? 0;
              if (pts <= 0) return;
              Navigator.pop(context);
              HapticFeedback.mediumImpact();
              final msg = await admin.updatePoints(
                userID: farmer.userID,
                delta:  isAdd ? pts : -pts,
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(msg),
                    backgroundColor: isAdd ? AppColors.success : AppColors.error,
                  ),
                );
              }
            },
            child: Text(isAdd ? 'Add' : 'Deduct'),
          ),
        ],
      ),
    );
  }

  Widget _miniEmpty(String msg) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: Center(child: Text(msg, style: const TextStyle(color: AppColors.textHint, fontSize: 13))),
  );

  String _formatTs(String ts) {
    try { return DateFormat('d MMM, hh:mm a').format(DateTime.parse(ts).toLocal()); }
    catch (_) { return ts; }
  }
}
