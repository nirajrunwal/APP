// ─────────────────────────────────────────────────────────────────
// lib/core/services/api_service.dart
// Centralised HTTP client for Google Apps Script REST API
// ─────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'package:http/http.dart' as http;

import '../constants/app_constants.dart';
import '../models/user_model.dart';
import '../models/location_log_model.dart';

class ApiException implements Exception {
  final String message;
  final int? code;
  ApiException(this.message, [this.code]);

  @override
  String toString() => 'ApiException($code): $message';
}

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final _baseUrl    = AppConstants.appsScriptUrl;
  final _secret     = AppConstants.apiSecret;
  final _httpClient = http.Client();

  // ── Private: parse Apps Script response ─────────────────────
  Map<String, dynamic> _parse(http.Response res) {
    if (res.statusCode != 200) {
      throw ApiException('HTTP ${res.statusCode}', res.statusCode);
    }
    final body = json.decode(res.body) as Map<String, dynamic>;
    if (body['success'] != true) {
      throw ApiException(
        body['error']?.toString() ?? 'Unknown error',
        int.tryParse(body['code']?.toString() ?? '400'),
      );
    }
    return body['data'] as Map<String, dynamic>? ?? {};
  }

  List<dynamic> _parseList(http.Response res) {
    if (res.statusCode != 200) {
      throw ApiException('HTTP ${res.statusCode}', res.statusCode);
    }
    final body = json.decode(res.body) as Map<String, dynamic>;
    if (body['success'] != true) {
      throw ApiException(
        body['error']?.toString() ?? 'Unknown error',
        int.tryParse(body['code']?.toString() ?? '400'),
      );
    }
    return body['data'] as List<dynamic>? ?? [];
  }

  // ── GET helper ───────────────────────────────────────────────
  Future<http.Response> _get(Map<String, String> params) async {
    params['secret'] = _secret;
    final uri = Uri.parse(_baseUrl).replace(queryParameters: params);
    return _httpClient.get(uri, headers: {'Accept': 'application/json'});
  }

  // ── POST helper ──────────────────────────────────────────────
  Future<http.Response> _post(Map<String, dynamic> body) async {
    body['secret'] = _secret;
    return _httpClient.post(
      Uri.parse(_baseUrl),
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
      body: json.encode(body),
    );
  }

  // ════════════════════════════════════════════════════════════
  // AUTH
  // ════════════════════════════════════════════════════════════

  /// Direct login with phone + password. Returns [UserModel] on success.
  /// No token/OTP — just credential match against the Users sheet.
  Future<UserModel> login({
    required String phone,
    required String password,
  }) async {
    final res  = await _post({'action': 'login', 'phone': phone, 'password': password});
    final data = _parse(res);
    return UserModel.fromJson(data['user'] as Map<String, dynamic>);
  }

  // ════════════════════════════════════════════════════════════
  // USERS
  // ════════════════════════════════════════════════════════════

  Future<List<UserModel>> getUsers() async {
    final res  = await _get({'action': 'getUsers'});
    final list = _parseList(res);
    return list.map((e) => UserModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<UserModel> registerUser({
    required String name,
    required String phone,
    required String password,
    required String role,
    required String village,
    String? profilePhoto,
  }) async {
    final res = await _post({
      'action': 'registerUser',
      'name': name,
      'phone': phone,
      'password': password,
      'role': role,
      'village': village,
      'profilePhoto': profilePhoto ?? '',
    });
    final data = _parse(res);
    return UserModel.fromJson(data);
  }

  Future<bool> deleteUser(String userID) async {
    final res = await _post({
      'action': 'deleteUser',
      'userID': userID,
    });
    final data = _parse(res);
    return data['deleted'] == true;
  }

  Future<({int loyaltyPoints, String name})> getFarmerPoints(String userID) async {
    final res  = await _get({'action': 'getFarmerPoints', 'userID': userID});
    final data = _parse(res);
    return (
      loyaltyPoints: int.tryParse(data['loyaltyPoints']?.toString() ?? '0') ?? 0,
      name: data['name']?.toString() ?? '',
    );
  }

  Future<({int previousPoints, int newPoints, int delta})> updatePoints({
    required String userID,
    required int delta,
  }) async {
    final res  = await _post({'action': 'updatePoints', 'userID': userID, 'delta': delta});
    final data = _parse(res);
    return (
      previousPoints: int.tryParse(data['previousPoints']?.toString() ?? '0') ?? 0,
      newPoints:      int.tryParse(data['newPoints']?.toString()      ?? '0') ?? 0,
      delta:          int.tryParse(data['delta']?.toString()          ?? '0') ?? 0,
    );
  }

  // ════════════════════════════════════════════════════════════
  // LOCATION LOGS
  // ════════════════════════════════════════════════════════════

  Future<List<LocationLog>> getLocationLogs({String? userID}) async {
    final params = <String, String>{'action': 'getLocationLogs'};
    if (userID != null) params['userID'] = userID;
    final res  = await _get(params);
    final list = _parseList(res);
    return list.map((e) => LocationLog.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Batch upload location entries.
  /// Returns number of breaches detected.
  Future<List<dynamic>> batchUploadLocations(List<Map<String, dynamic>> locations) async {
    final res  = await _post({'action': 'batchUploadLocations', 'locations': locations});
    final data = _parse(res);
    return data['proximityBreaches'] as List<dynamic>? ?? [];
  }

  // ════════════════════════════════════════════════════════════
  // SHOP SETTINGS
  // ════════════════════════════════════════════════════════════

  Future<List<dynamic>> getShopSettings() async {
    final res  = await _get({'action': 'getShopSettings'});
    return _parseList(res);
  }

  // ════════════════════════════════════════════════════════════
  // PING
  // ════════════════════════════════════════════════════════════

  Future<bool> ping() async {
    try {
      final res  = await _get({'action': 'ping'});
      final data = _parse(res);
      return data['message'] != null;
    } catch (_) {
      return false;
    }
  }
}
