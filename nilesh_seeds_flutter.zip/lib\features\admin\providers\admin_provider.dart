// ─────────────────────────────────────────────────────────────────
// lib/features/admin/providers/admin_provider.dart
// ─────────────────────────────────────────────────────────────────

import 'dart:async';
import 'package:flutter/foundation.dart';

import '../../../core/models/location_log_model.dart';
import '../../../core/models/user_model.dart';
import '../../../core/services/api_service.dart';

class AdminProvider extends ChangeNotifier {
  List<UserModel>   _farmers          = [];
  List<LocationLog> _allLogs          = [];
  bool              _isLoading        = false;
  String            _error            = '';
  List<LocationLog> _recentBreaches   = [];

  List<UserModel>   get farmers         => _farmers;
  List<LocationLog> get allLogs         => _allLogs;
  bool              get isLoading       => _isLoading;
  String            get error           => _error;
  List<LocationLog> get recentBreaches  => _recentBreaches;

  int get activeFarmerCount {
    final cutoff = DateTime.now().subtract(const Duration(hours: 1));
    final activeIDs = _allLogs
        .where((l) {
          try { return DateTime.parse(l.timestamp).isAfter(cutoff); } catch (_) { return false; }
        })
        .map((l) => l.userID)
        .toSet();
    return activeIDs.length;
  }

  // ── Full refresh ─────────────────────────────────────────────
  Future<void> refresh() async {
    _isLoading = true;
    _error     = '';
    notifyListeners();

    try {
      final results = await Future.wait([
        ApiService().getUsers(),
        ApiService().getLocationLogs(),
      ]);

      final users = results[0] as List<UserModel>;
      _farmers    = users.where((u) => !u.isAdmin).toList();

      _allLogs         = results[1] as List<LocationLog>;
      _recentBreaches  = _allLogs.where((l) => l.isProximityBreach).take(50).toList();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ── Update loyalty points ─────────────────────────────────────
  Future<String> updatePoints({required String userID, required int delta}) async {
    try {
      final result = await ApiService().updatePoints(userID: userID, delta: delta);
      // Refresh farmer list
      await refresh();
      return 'Points updated! New total: ${result.newPoints}';
    } on ApiException catch (e) {
      return 'Error: ${e.message}';
    } catch (e) {
      return 'Error: $e';
    }
  }

  // ── Register farmer ──────────────────────────────────────────
  Future<String> registerUser({
    required String name,
    required String phone,
    required String password,
    required String village,
    String? profilePhoto,
  }) async {
    _isLoading = true;
    notifyListeners();
    try {
      await ApiService().registerUser(
        name: name,
        phone: phone,
        password: password,
        role: 'Farmer',
        village: village,
        profilePhoto: profilePhoto,
      );
      await refresh();
      return 'Farmer registered successfully!';
    } on ApiException catch (e) {
      return 'Error: ${e.message}';
    } catch (e) {
      return 'Error: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ── Delete farmer ────────────────────────────────────────────
  Future<String> deleteUser(String userID) async {
    _isLoading = true;
    notifyListeners();
    try {
      final success = await ApiService().deleteUser(userID);
      if (success) {
        await refresh();
        return 'Farmer deleted successfully!';
      } else {
        return 'Failed to delete farmer.';
      }
    } on ApiException catch (e) {
      return 'Error: ${e.message}';
    } catch (e) {
      return 'Error: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ── Get farmer name by ID ─────────────────────────────────────
  String farmerName(String userID) {
    try {
      return _farmers.firstWhere((f) => f.userID == userID).name;
    } catch (_) {
      return userID;
    }
  }
}
