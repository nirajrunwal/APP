// ─────────────────────────────────────────────────────────────────
// lib/core/constants/app_constants.dart
// ─────────────────────────────────────────────────────────────────

class AppConstants {
  AppConstants._();

  // ── Replace with your deployed Apps Script Web App URL ──
  static const String appsScriptUrl =
      'https://script.google.com/macros/s/AKfycbwTxxlcPkxqDbqKgOacENvkOJhQaC7idJgusvvUhq84lFgK3h7qaHx3AjfwLR6wAAw0TA/exec';

  // ── Must match the API_SECRET in Code.gs ──
  static const String apiSecret = 'NileshSeeds_SecKey_2026';

  // ── Hive
  static const String hiveBoxName = 'agri_loyalty_cache';

  // ── Cache keys
  static const String kUserData     = 'user_data';
  static const String kShopSettings = 'shop_settings';

  // ── Location
  static const int locationUploadIntervalMinutes = 60; // 1 hour
  static const double defaultGeofenceRadius = 300.0;   // metres

  // ── Polling
  static const int adminPollingSeconds = 30;
  static const int farmerPollingSeconds = 60;
}
