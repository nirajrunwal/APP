// ─────────────────────────────────────────────────────────────────
// lib/core/theme/app_theme.dart
// Material Design 3 — Dark Green & White Agricultural Theme
// ─────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  AppColors._();

  // ── Primary greens
  static const Color primary         = Color(0xFF2E7D32);
  static const Color primaryLight    = Color(0xFF4CAF50);
  static const Color primaryDark     = Color(0xFF1B5E20);
  static const Color primaryGlow     = Color(0xFF66BB6A);

  // ── Dark backgrounds
  static const Color bgBase          = Color(0xFF0D1B12);
  static const Color bgSurface       = Color(0xFF122118);
  static const Color bgCard          = Color(0xFF1A2E1F);
  static const Color bgElevated      = Color(0xFF1E3526);

  // ── Accent & status
  static const Color accent          = Color(0xFF00E676);
  static const Color warning         = Color(0xFFFFB300);
  static const Color error           = Color(0xFFEF5350);
  static const Color info            = Color(0xFF42A5F5);
  static const Color success         = Color(0xFF4CAF50);

  // ── Text
  static const Color textPrimary     = Color(0xFFF5F5F5);
  static const Color textSecondary   = Color(0xFFB0BEC5);
  static const Color textHint        = Color(0xFF607D8B);
  static const Color textOnPrimary   = Colors.white;

  // ── Border / dividers
  static const Color border          = Color(0xFF2A3D2E);
  static const Color divider         = Color(0xFF1E3526);

  // ── Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFF1A2E1F), Color(0xFF122118)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient glowGradient = LinearGradient(
    colors: [Color(0xFF00E676), Color(0xFF4CAF50)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
}

class AppTheme {
  AppTheme._();

  static ThemeData get darkTheme {
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: AppColors.textPrimary,
      displayColor: AppColors.textPrimary,
    );

    return base.copyWith(
      colorScheme: const ColorScheme.dark(
        primary:          AppColors.primary,
        onPrimary:        AppColors.textOnPrimary,
        secondary:        AppColors.primaryLight,
        onSecondary:      AppColors.textOnPrimary,
        tertiary:         AppColors.accent,
        surface:          AppColors.bgSurface,
        onSurface:        AppColors.textPrimary,
        error:            AppColors.error,
        onError:          Colors.white,
      ),
      scaffoldBackgroundColor: AppColors.bgBase,
      textTheme: textTheme,
      primaryTextTheme: textTheme,

      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.bgBase,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.inter(
          color: AppColors.textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w600,
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 56),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
          textStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.bgCard,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.primaryLight, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.error),
        ),
        labelStyle: const TextStyle(color: AppColors.textSecondary),
        hintStyle: const TextStyle(color: AppColors.textHint),
        prefixIconColor: AppColors.textSecondary,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
      ),

      cardTheme: CardTheme(
        color: AppColors.bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.border, width: 1),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
      ),

      chipTheme: ChipThemeData(
        backgroundColor: AppColors.bgElevated,
        selectedColor: AppColors.primary,
        labelStyle: GoogleFonts.inter(fontSize: 12, color: AppColors.textPrimary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        side: const BorderSide(color: AppColors.border),
      ),

      dividerTheme: const DividerThemeData(
        color: AppColors.divider,
        thickness: 1,
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.bgElevated,
        contentTextStyle: GoogleFonts.inter(color: AppColors.textPrimary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),

      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.bgSurface,
        selectedItemColor: AppColors.primaryGlow,
        unselectedItemColor: AppColors.textHint,
        elevation: 0,
      ),
    );
  }

  static ThemeData get lightTheme => darkTheme; // App is dark-mode only
}
