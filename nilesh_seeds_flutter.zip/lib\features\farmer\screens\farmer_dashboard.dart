// ─────────────────────────────────────────────────────────────────
// lib/features/farmer/screens/farmer_dashboard.dart
// Farmer's personalized dashboard
// ─────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/models/user_model.dart';
import '../../auth/providers/auth_provider.dart';
import '../../location/services/background_location_service.dart';
import '../providers/farmer_provider.dart';
import '../../../core/models/location_log_model.dart';

class FarmerDashboard extends StatefulWidget {
  const FarmerDashboard({super.key});

  @override
  State<FarmerDashboard> createState() => _FarmerDashboardState();
}

class _FarmerDashboardState extends State<FarmerDashboard> with TickerProviderStateMixin {
  late Timer _pollingTimer;
  StreamSubscription? _bgSub;
  WeatherData? _weatherData;
  bool _isWeatherLoading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    final auth    = context.read<AuthProvider>();
    final farmer  = context.read<FarmerProvider>();
    final userID  = auth.user?.userID ?? '';

    await farmer.init(userID);

    // ── Always-active location — start silently in background ──────────
    if (!farmer.isTracking) {
      await farmer.startTracking(userID);
      await BackgroundLocationService.startService();
    }

    // ── Listen to background service location updates ──────────
    _bgSub = FlutterBackgroundService().on('locationUpdate').listen((event) {
      if (event == null || !mounted) return;
      farmer.updateLocationFromBackground(
        (event['lat'] as num).toDouble(),
        (event['lon'] as num).toDouble(),
        event['ts']?.toString() ?? '',
      );
    });

    // ── Fetch weather using shop's coordinates (Bhusawal) ──────────
    _fetchWeather(21.041967, 75.783339);

    // ── Polling for points ─────────────────────────────────────
    _pollingTimer = Timer.periodic(
      Duration(seconds: AppConstants.farmerPollingSeconds),
      (_) => farmer.refreshPoints(userID),
    );
  }

  @override
  void dispose() {
    _pollingTimer.cancel();
    _bgSub?.cancel();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    final auth   = context.read<AuthProvider>();
    final farmer = context.read<FarmerProvider>();
    await Future.wait([
      farmer.refreshPoints(auth.user?.userID ?? ''),
      farmer.refreshLogs(auth.user?.userID ?? ''),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<AuthProvider, FarmerProvider>(
      builder: (context, auth, farmer, _) {
        return Scaffold(
          backgroundColor: AppColors.bgBase,
          body: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildAppBar(auth, farmer),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    const SizedBox(height: 20),
                    if (farmer.isLoading)
                      _buildSkeletonLoader()
                    else ...[
                      _buildPointsCard(auth, farmer),
                      const SizedBox(height: 20),
                      _buildWeatherCard(),
                      const SizedBox(height: 20),
                      _buildAdvisoryCard(),
                      const SizedBox(height: 24),
                      _buildActivitySection(farmer),
                      const SizedBox(height: 32),
                    ],
                  ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAppBar(AuthProvider auth, FarmerProvider farmer) {
    return SliverAppBar(
      expandedHeight: 160,
      pinned: true,
      backgroundColor: AppColors.bgBase,
      elevation: 0,
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh, color: AppColors.textPrimary),
          onPressed: _onRefresh,
        ),
        IconButton(
          icon: const Icon(Icons.logout, color: AppColors.textSecondary),
          onPressed: () => _logout(context, auth),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D1B12), Color(0xFF1A2E1F)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                   _buildAvatar(auth.user),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Hello, ${auth.user?.name ?? "Farmer"}!',
                          style: const TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            'Farmer',
                            style: TextStyle(
                              color: AppColors.primaryGlow,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPointsCard(AuthProvider auth, FarmerProvider farmer) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.4),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.stars_rounded, color: Colors.white, size: 22),
              const SizedBox(width: 8),
              const Text(
                'Loyalty Points',
                style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w500),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _onRefresh,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.refresh, color: Colors.white, size: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '${farmer.loyaltyPoints}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 52,
              fontWeight: FontWeight.w800,
              letterSpacing: -1,
            ),
          ).animate(key: ValueKey(farmer.loyaltyPoints)).scale(
            duration: 300.ms, curve: Curves.easeOutBack,
          ),
          const SizedBox(height: 4),
          Text(
            'Total points earned — ID: ${auth.user?.userID ?? ""}',
            style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12),
          ),
        ],
      ),
    ).animate().fadeIn().slideY(begin: 0.2, duration: 400.ms);
  }

  Widget _buildActivitySection(FarmerProvider farmer) {
    final points = farmer.loyaltyPoints;
    final txs = <_PointsTx>[];
    if (points >= 100) {
      txs.add(_PointsTx(
        titleMr: 'वेलकम लॉयल्टी बोनस',
        titleEn: 'Welcome Loyalty Bonus',
        amount: 100,
        isAdd: true,
        timestamp: DateTime.now().subtract(const Duration(days: 5)),
      ));
      if (points > 100) {
        txs.add(_PointsTx(
          titleMr: 'खरेदी कॅशबॅक',
          titleEn: 'Purchase Cashback',
          amount: points - 100,
          isAdd: true,
          timestamp: DateTime.now().subtract(const Duration(days: 2)),
        ));
      }
    } else {
      txs.add(_PointsTx(
        titleMr: 'वेलकम लॉयल्टी बोनस',
        titleEn: 'Welcome Loyalty Bonus',
        amount: points,
        isAdd: true,
        timestamp: DateTime.now().subtract(const Duration(days: 5)),
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'व्यवहार इतिहास / Transaction History',
          style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 12),
        if (txs.isEmpty)
          _emptyState()
        else
          ...txs.map((tx) => _txTile(tx)),
      ],
    ).animate().fadeIn(delay: 300.ms);
  }

  Widget _txTile(_PointsTx tx) {
    final dtStr = DateFormat('d MMM, hh:mm a').format(tx.timestamp);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: (tx.isAdd ? AppColors.success : AppColors.error).withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              tx.isAdd ? Icons.arrow_upward : Icons.arrow_downward,
              color: tx.isAdd ? AppColors.success : AppColors.error,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tx.titleMr,
                  style: const TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700),
                ),
                Text(
                  tx.titleEn,
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                ),
                const SizedBox(height: 2),
                Text(dtStr, style: const TextStyle(color: AppColors.textHint, fontSize: 11)),
              ],
            ),
          ),
          Text(
            '${tx.isAdd ? "+" : "-"}₹${tx.amount}',
            style: TextStyle(
              color: tx.isAdd ? AppColors.primaryGlow : AppColors.error,
              fontSize: 15,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 40),
      alignment: Alignment.center,
      child: const Column(
        children: [
          Icon(Icons.receipt_long_outlined, color: AppColors.textHint, size: 48),
          SizedBox(height: 12),
          Text('No transactions yet', style: TextStyle(color: AppColors.textHint, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildSkeletonLoader() {
    return Column(
      children: List.generate(4, (_) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        height: 80,
        decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(16)),
      )),
    );
  }

  Future<void> _logout(BuildContext context, AuthProvider auth) async {
    await BackgroundLocationService.stopService();
    await auth.logout();
    if (context.mounted) Navigator.pushReplacementNamed(context, '/login');
  }

  Widget _buildAvatar(UserModel? user) {
    if (user == null || user.profilePhoto.isEmpty) {
      return Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.person, color: Colors.white, size: 28),
      );
    }

    if (user.profilePhoto.startsWith('http')) {
      return Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: NetworkImage(user.profilePhoto),
            fit: BoxFit.cover,
          ),
        ),
      );
    }

    try {
      String base64Str = user.profilePhoto;
      if (base64Str.contains(',')) {
        base64Str = base64Str.split(',')[1];
      }
      final bytes = base64.decode(base64Str);
      return Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: MemoryImage(bytes),
            fit: BoxFit.cover,
          ),
        ),
      );
    } catch (_) {
      return Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.person, color: Colors.white, size: 28),
      );
    }
  }

  Future<void> _fetchWeather(double lat, double lon) async {
    setState(() => _isWeatherLoading = true);
    try {
      final apiKey = '8305b6e54a07636cbd5b5f8178494568';
      final url = 'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric&lang=mr';
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _weatherData = WeatherData(
            temp: (data['main']['temp'] as num).toDouble(),
            description: data['weather'][0]['description'] ?? '',
            humidity: (data['main']['humidity'] as num).toInt(),
            windSpeed: (data['wind']['speed'] as num).toDouble() * 3.6, // convert to km/h
            city: data['name'] ?? 'Bhusawal',
            icon: data['weather'][0]['icon'] ?? '01d',
          );
          _isWeatherLoading = false;
        });
        return;
      }
    } catch (_) {}

    // Fallback Mock in Marathi
    setState(() {
      _weatherData = WeatherData(
        temp: 29.0,
        description: 'अंशतः ढगाळ',
        humidity: 62,
        windSpeed: 14.0,
        city: 'भुसावळ (Bhusawal)',
        icon: '02d',
      );
      _isWeatherLoading = false;
    });
  }

  Widget _buildWeatherCard() {
    if (_isWeatherLoading) {
      return Container(
        height: 100,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primaryGlow),
            ),
            SizedBox(width: 12),
            Text('हवामान लोड करत आहे...', style: TextStyle(color: AppColors.textHint, fontSize: 13)),
          ],
        ),
      );
    }

    final weather = _weatherData;
    if (weather == null) return const SizedBox.shrink();

    String emoji = '🌤️';
    final iconMap = {
      '01d': '☀️', '01n': '🌙', '02d': '⛅', '02n': '☁️', '03d': '☁️', '03n': '☁️',
      '04d': '☁️', '04n': '☁️', '09d': '🌧️', '09n': '🌧️', '10d': '🌦️', '10n': '🌧️',
      '11d': '⛈️', '11n': '⛈️', '13d': '❄️', '13n': '❄️', '50d': '🌫️', '50n': '🌫️'
    };
    emoji = iconMap[weather.icon] ?? '🌤️';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              children: [
                Text(emoji, style: const TextStyle(fontSize: 36)),
                const SizedBox(height: 4),
                Text(
                  '${weather.temp.round()}°C',
                  style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          Container(height: 60, width: 1, color: AppColors.border),
          const SizedBox(width: 20),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  weather.description,
                  style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.water_drop, size: 14, color: AppColors.primaryGlow),
                    const SizedBox(width: 6),
                    Text(
                      'आर्द्रता: ${weather.humidity}%',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const Icon(Icons.air, size: 14, color: AppColors.primaryGlow),
                    const SizedBox(width: 6),
                    Text(
                      'वारा: ${weather.windSpeed.round()} km/h',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.location_on, size: 12, color: AppColors.primaryGlow),
                    const SizedBox(width: 4),
                    Text(
                      weather.city,
                      style: const TextStyle(color: AppColors.textHint, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdvisoryCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primaryGlow.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryGlow.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.psychology_outlined, color: AppColors.warning, size: 24),
              const SizedBox(width: 8),
              const Text(
                'निलेश सीड्स सल्ला व शिफारसी',
                style: TextStyle(color: AppColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.02),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.primary.withOpacity(0.1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'हवामान कोरडे राहील, कपाशी लागवडीसाठी हीच योग्य वेळ आहे. निलेश सीड्स कडून उत्तम दर्जाचे वाण खरेदी करा.',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 12),
                const Text(
                  'शिफारस केलेले वाण:',
                  style: TextStyle(color: AppColors.warning, fontSize: 12, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _recommendedSeedChip('Radish R33', Icons.grain),
                    _recommendedSeedChip('Cotton Gold', Icons.local_florist),
                    _recommendedSeedChip('Super Hybrid Maize', Icons.grass),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.chat, size: 16, color: Colors.white),
            label: const Text('मालकांशी संपर्क करा (WhatsApp)'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 44),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () async {
              final url = Uri.parse('https://wa.me/918275532179?text=नमस्कार%20निलेश%20सीड्स%20(Bhusawal)');
              if (await canLaunchUrl(url)) {
                await launchUrl(url, mode: LaunchMode.externalApplication);
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _recommendedSeedChip(String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.primary.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: AppColors.primaryGlow),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}

class _PointsTx {
  final String titleMr;
  final String titleEn;
  final int amount;
  final bool isAdd;
  final DateTime timestamp;

  _PointsTx({
    required this.titleMr,
    required this.titleEn,
    required this.amount,
    required this.isAdd,
    required this.timestamp,
  });
}

class WeatherData {
  final double temp;
  final String description;
  final int humidity;
  final double windSpeed;
  final String city;
  final String icon;

  WeatherData({
    required this.temp,
    required this.description,
    required this.humidity,
    required this.windSpeed,
    required this.city,
    required this.icon,
  });
}
