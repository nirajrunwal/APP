// ─────────────────────────────────────────────────────────────────
// lib/features/location/services/location_service.dart
// GPS tracking + Haversine geofencing
// ─────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:geolocator/geolocator.dart';

class LocationService {
  static final LocationService _instance = LocationService._internal();
  factory LocationService() => _instance;
  LocationService._internal();

  // ── Request location permissions ─────────────────────────────
  Future<bool> requestPermissions() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return false;
    }

    if (permission == LocationPermission.deniedForever) return false;

    return true;
  }

  // ── Get current position ─────────────────────────────────────
  Future<Position?> getCurrentPosition() async {
    final granted = await requestPermissions();
    if (!granted) return null;

    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 30),
        ),
      );
    } catch (e) {
      return null;
    }
  }

  // ── Haversine distance (metres) ───────────────────────────────
  double haversineDistance({
    required double lat1, required double lon1,
    required double lat2, required double lon2,
  }) {
    const R = 6371000.0; // Earth radius metres
    final dLat = _toRad(lat2 - lat1);
    final dLon = _toRad(lon2 - lon1);

    final a = math.sin(dLat / 2) * math.sin(dLat / 2)
      + math.cos(_toRad(lat1)) * math.cos(_toRad(lat2))
      * math.sin(dLon / 2) * math.sin(dLon / 2);

    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return R * c;
  }

  double _toRad(double deg) => deg * math.pi / 180;

  // ── Is within geofence? ──────────────────────────────────────
  bool isWithinGeofence({
    required double farmerLat, required double farmerLon,
    required double shopLat,   required double shopLon,
    double radiusMetres = 300,
  }) {
    final dist = haversineDistance(
      lat1: farmerLat, lon1: farmerLon,
      lat2: shopLat,   lon2: shopLon,
    );
    return dist <= radiusMetres;
  }

  // ── Location stream (foreground) ─────────────────────────────
  Stream<Position> getPositionStream() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 50, // metres
      ),
    );
  }
}
