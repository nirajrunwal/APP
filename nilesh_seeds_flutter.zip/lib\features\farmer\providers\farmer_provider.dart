// ─────────────────────────────────────────────────────────────────
// lib/features/farmer/providers/farmer_provider.dart
// ─────────────────────────────────────────────────────────────────

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/models/location_log_model.dart';
import '../../../core/models/shop_settings_model.dart';
import '../../../core/services/api_service.dart';
import '../../location/services/location_service.dart';

class FarmerProvider extends ChangeNotifier {
  int               _loyaltyPoints      = 0;
  List<LocationLog> _myLogs             = [];
  ShopSettings?     _shopSettings;
  bool              _isLoading          = false;
  bool              _isTracking         = false;
  bool              _withinGeofence     = false;
  double?           _lastLat;
  double?           _lastLon;
  String            _lastLocationTs     = '';
  String            _error              = '';

  int               get loyaltyPoints   => _loyaltyPoints;
  List<LocationLog> get myLogs          => _myLogs;
  ShopSettings?     get shopSettings    => _shopSettings;
  bool              get isLoading       => _isLoading;
  bool              get isTracking      => _isTracking;
  bool              get withinGeofence  => _withinGeofence;
  double?           get lastLat         => _lastLat;
  double?           get lastLon         => _lastLon;
  String            get lastLocationTs  => _lastLocationTs;
  String            get error           => _error;

  final _locationService = LocationService();

  // ── Init farmer data ─────────────────────────────────────────
  Future<void> init(String userID) async {
    _isLoading = true;
    _error     = '';
    notifyListeners();

    try {
      // Restore cached location
      final prefs = await SharedPreferences.getInstance();
      _lastLat        = prefs.getDouble('lastLat');
      _lastLon        = prefs.getDouble('lastLon');
      _lastLocationTs = prefs.getString('lastLocationTs') ?? '';

      // Parallel fetch
      final results = await Future.wait([
        ApiService().getFarmerPoints(userID),
        ApiService().getLocationLogs(userID: userID),
        ApiService().getShopSettings(),
      ]);

      final pointsResult = results[0] as ({int loyaltyPoints, String name});
      _loyaltyPoints = pointsResult.loyaltyPoints;

      final logsResult = results[1] as List<LocationLog>;
      _myLogs = logsResult;

      final shopsResult = results[2] as List<dynamic>;
      if (shopsResult.isNotEmpty) {
        _shopSettings = ShopSettings.fromJson(shopsResult[0] as Map<String, dynamic>);
        _recalcGeofence();
      }
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ── Refresh points only (pull-to-refresh) ────────────────────
  Future<void> refreshPoints(String userID) async {
    try {
      final result = await ApiService().getFarmerPoints(userID);
      _loyaltyPoints = result.loyaltyPoints;
      notifyListeners();
    } catch (_) {}
  }

  // ── Refresh logs ─────────────────────────────────────────────
  Future<void> refreshLogs(String userID) async {
    try {
      _myLogs = await ApiService().getLocationLogs(userID: userID);
      notifyListeners();
    } catch (_) {}
  }

  // ── Toggle tracking ──────────────────────────────────────────
  Future<void> startTracking(String userID) async {
    final granted = await _locationService.requestPermissions();
    if (!granted) {
      _error = 'Location permission denied';
      notifyListeners();
      return;
    }
    _isTracking = true;
    notifyListeners();

    // Update current position
    final pos = await _locationService.getCurrentPosition();
    if (pos != null) {
      _lastLat        = pos.latitude;
      _lastLon        = pos.longitude;
      _lastLocationTs = DateTime.now().toIso8601String();
      _recalcGeofence();
      notifyListeners();
    }
  }

  void stopTracking() {
    _isTracking = false;
    notifyListeners();
  }

  // ── Update location from background service event ─────────────
  void updateLocationFromBackground(double lat, double lon, String ts) {
    _lastLat        = lat;
    _lastLon        = lon;
    _lastLocationTs = ts;
    _recalcGeofence();
    notifyListeners();
  }

  void _recalcGeofence() {
    if (_shopSettings == null || _lastLat == null || _lastLon == null) return;
    _withinGeofence = _locationService.isWithinGeofence(
      farmerLat: _lastLat!,
      farmerLon: _lastLon!,
      shopLat:   _shopSettings!.latitude,
      shopLon:   _shopSettings!.longitude,
      radiusMetres: _shopSettings!.geofenceRadiusMeter,
    );
  }
}
