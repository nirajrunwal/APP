// ─────────────────────────────────────────────────────────────────
// lib/core/models/location_log_model.dart
// ─────────────────────────────────────────────────────────────────

class LocationLog {
  final String logID;
  final String userID;
  final double latitude;
  final double longitude;
  final String timestamp;
  final bool isProximityBreach;

  const LocationLog({
    required this.logID,
    required this.userID,
    required this.latitude,
    required this.longitude,
    required this.timestamp,
    required this.isProximityBreach,
  });

  factory LocationLog.fromJson(Map<String, dynamic> json) => LocationLog(
    logID:    json['LogID']?.toString()    ?? '',
    userID:   json['UserID']?.toString()   ?? '',
    latitude:  double.tryParse(json['Latitude']?.toString()  ?? '0') ?? 0.0,
    longitude: double.tryParse(json['Longitude']?.toString() ?? '0') ?? 0.0,
    timestamp: json['Timestamp']?.toString() ?? '',
    isProximityBreach: json['IsProximityBreach'] == true ||
                       json['IsProximityBreach']?.toString().toLowerCase() == 'true',
  );

  Map<String, dynamic> toJson() => {
    'LogID':             logID,
    'UserID':            userID,
    'Latitude':          latitude,
    'Longitude':         longitude,
    'Timestamp':         timestamp,
    'IsProximityBreach': isProximityBreach,
  };
}

// ─────────────────────────────────────────────────────────────────
// lib/core/models/shop_settings_model.dart
// ─────────────────────────────────────────────────────────────────

class ShopSettings {
  final String shopID;
  final String name;
  final double latitude;
  final double longitude;
  final double geofenceRadiusMeter;

  const ShopSettings({
    required this.shopID,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.geofenceRadiusMeter,
  });

  factory ShopSettings.fromJson(Map<String, dynamic> json) => ShopSettings(
    shopID:               json['ShopID']?.toString() ?? '',
    name:                 json['Name']?.toString()   ?? '',
    latitude:             double.tryParse(json['Latitude']?.toString()  ?? '0') ?? 0.0,
    longitude:            double.tryParse(json['Longitude']?.toString() ?? '0') ?? 0.0,
    geofenceRadiusMeter:  double.tryParse(json['GeofenceRadiusMeter']?.toString() ?? '300') ?? 300.0,
  );
}
