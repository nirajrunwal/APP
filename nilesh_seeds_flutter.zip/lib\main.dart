// ─────────────────────────────────────────────────────────────────
// lib/main.dart — Application Entry Point
// AgriLoyalty Flutter App
// ─────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/farmer/providers/farmer_provider.dart';
import 'features/admin/providers/admin_provider.dart';
import 'features/location/services/location_service.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/farmer/screens/farmer_dashboard.dart';
import 'features/admin/screens/admin_dashboard.dart';

// ── Background service entrypoint (runs in isolate)
import 'features/location/services/background_location_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── System UI Overlay
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // ── Initialise Hive local storage
  await Hive.initFlutter();
  await Hive.openBox(AppConstants.hiveBoxName);

  // ── Initialise background service
  await BackgroundLocationService.initialize();

  runApp(const AgriLoyaltyApp());
}

class AgriLoyaltyApp extends StatelessWidget {
  const AgriLoyaltyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => FarmerProvider()),
        ChangeNotifierProvider(create: (_) => AdminProvider()),
        Provider(create: (_) => LocationService()),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, auth, _) {
          return MaterialApp(
            title: 'Nilesh Seeds',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: ThemeMode.dark,
            initialRoute: '/',
            routes: {
              '/': (_) => const RootRouter(),
              '/login': (_) => const LoginScreen(),
              '/farmer': (_) => const FarmerDashboard(),
              '/admin': (_) => const AdminDashboard(),
            },
          );
        },
      ),
    );
  }
}

/// Decides the initial screen based on cached auth state.
class RootRouter extends StatefulWidget {
  const RootRouter({super.key});

  @override
  State<RootRouter> createState() => _RootRouterState();
}

class _RootRouterState extends State<RootRouter> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkAuth());
  }

  Future<void> _checkAuth() async {
    final auth = context.read<AuthProvider>();
    await auth.tryAutoLogin();

    if (!mounted) return;

    if (!auth.isLoggedIn) {
      Navigator.pushReplacementNamed(context, '/login');
    } else if (auth.isAdmin) {
      Navigator.pushReplacementNamed(context, '/admin');
    } else {
      Navigator.pushReplacementNamed(context, '/farmer');
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF0D1B12),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _SplashLogo(),
            SizedBox(height: 24),
            CircularProgressIndicator(color: Color(0xFF4CAF50)),
          ],
        ),
      ),
    );
  }
}

class _SplashLogo extends StatelessWidget {
  const _SplashLogo();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF2E7D32), Color(0xFF66BB6A)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF4CAF50).withOpacity(0.4),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: const Icon(Icons.agriculture, color: Colors.white, size: 52),
        ),
        const SizedBox(height: 20),
        const Text(
          'Nilesh Seeds',
          style: TextStyle(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'निलेश सीड्स, भुसावळ',
          style: TextStyle(
            color: Colors.white.withOpacity(0.6),
            fontSize: 14,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}
