// ─────────────────────────────────────────────────────────────────
// lib/core/models/user_model.dart
// ─────────────────────────────────────────────────────────────────

class UserModel {
  final String userID;
  final String name;
  final String phone;
  final String role;
  final int loyaltyPoints;
  final String createdAt;
  final String village;
  final String profilePhoto;

  const UserModel({
    required this.userID,
    required this.name,
    required this.phone,
    required this.role,
    required this.loyaltyPoints,
    required this.createdAt,
    required this.village,
    required this.profilePhoto,
  });

  bool get isAdmin => role.toLowerCase() == 'admin';

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    userID:        json['UserID']?.toString() ?? '',
    name:          json['Name']?.toString()   ?? '',
    phone:         json['Phone']?.toString()  ?? '',
    role:          json['Role']?.toString()   ?? 'Farmer',
    loyaltyPoints: int.tryParse(json['LoyaltyPoints']?.toString() ?? '0') ?? 0,
    createdAt:     json['CreatedAt']?.toString() ?? '',
    village:       json['Village']?.toString() ?? '',
    profilePhoto:  json['ProfilePhoto']?.toString() ?? '',
  );

  Map<String, dynamic> toJson() => {
    'UserID':        userID,
    'Name':          name,
    'Phone':         phone,
    'Role':          role,
    'LoyaltyPoints': loyaltyPoints,
    'CreatedAt':     createdAt,
    'Village':       village,
    'ProfilePhoto':  profilePhoto,
  };

  UserModel copyWith({
    int? loyaltyPoints,
    String? village,
    String? profilePhoto,
  }) => UserModel(
    userID:        userID,
    name:          name,
    phone:         phone,
    role:          role,
    loyaltyPoints: loyaltyPoints ?? this.loyaltyPoints,
    createdAt:     createdAt,
    village:       village ?? this.village,
    profilePhoto:  profilePhoto ?? this.profilePhoto,
  );
}
