// ─────────────────────────────────────────────────────────────────
// lib/features/auth/providers/auth_provider.dart
// Direct phone+password login — no tokens, no OTP
// ─────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/models/user_model.dart';
import '../../../core/services/api_service.dart';

enum AuthStatus { initial, loading, authenticated, unauthenticated, error }

class AuthProvider extends ChangeNotifier {
  AuthStatus _status  = AuthStatus.initial;
  UserModel? _user;
  String     _error   = '';

  AuthStatus get status   => _status;
  UserModel? get user     => _user;
  String     get error    => _error;
  bool get isLoggedIn     => _status == AuthStatus.authenticated && _user != null;
  bool get isLoading      => _status == AuthStatus.loading;
  bool get isAdmin        => _user?.isAdmin ?? false;

  // ── Auto-login from cached user data ──────────────────────────
  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getString('user_data');

    if (raw == null || raw.isEmpty) {
      _status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }

    try {
      _user   = UserModel.fromJson(json.decode(raw) as Map<String, dynamic>);
      _status = AuthStatus.authenticated;
    } catch (_) {
      _status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  // ── Direct Login — phone + password only ──────────────────────
  Future<bool> login({required String phone, required String password}) async {
    _status = AuthStatus.loading;
    _error  = '';
    notifyListeners();

    try {
      _user   = await ApiService().login(phone: phone, password: password);
      _status = AuthStatus.authenticated;

      // Persist user data for auto-login
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_data', json.encode(_user!.toJson()));
      await prefs.setString('userID',    _user!.userID);

      notifyListeners();
      return true;
    } on ApiException catch (e) {
      _error  = e.message;
      _status = AuthStatus.error;
      notifyListeners();
      return false;
    } catch (e) {
      _error  = 'Network error. Check your connection.';
      _status = AuthStatus.error;
      notifyListeners();
      return false;
    }
  }

  // ── Logout ────────────────────────────────────────────────────
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user_data');
    await prefs.remove('userID');
    await prefs.remove('lastLat');
    await prefs.remove('lastLon');
    await prefs.remove('lastLocationTs');

    _user   = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }

  // ── Update points locally ─────────────────────────────────────
  void updateLocalPoints(int newPoints) {
    if (_user == null) return;
    _user = _user!.copyWith(loyaltyPoints: newPoints);
    notifyListeners();
  }
}
